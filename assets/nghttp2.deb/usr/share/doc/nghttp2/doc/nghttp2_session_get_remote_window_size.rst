
nghttp2_session_get_remote_window_size
======================================

Synopsis
--------

*#include <nghttp2/nghttp2.h>*

.. function:: int32_t nghttp2_session_get_remote_window_size(nghttp2_session *session)

    
    Returns the remote window size for a connection.
    
    This function always succeeds.
