
nghttp2_hd_inflate_change_table_size
====================================

Synopsis
--------

*#include <nghttp2/nghttp2.h>*

.. function:: int nghttp2_hd_inflate_change_table_size(nghttp2_hd_inflater *inflater, size_t settings_hd_table_bufsize_max)

    
    Changes header table size in the *inflater*.  This may trigger
    eviction in the dynamic table.
    
    The *settings_hd_table_bufsize_max* should be the value transmitted
    in SETTINGS_HEADER_TABLE_SIZE.
    
    This function returns 0 if it succeeds, or one of the following
    negative error codes:
    
    :macro:`NGHTTP2_ERR_NOMEM`
        Out of memory.
