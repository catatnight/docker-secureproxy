
nghttp2_hd_inflate_del
======================

Synopsis
--------

*#include <nghttp2/nghttp2.h>*

.. function:: void nghttp2_hd_inflate_del(nghttp2_hd_inflater *inflater)

    
    Deallocates any resources allocated for *inflater*.
