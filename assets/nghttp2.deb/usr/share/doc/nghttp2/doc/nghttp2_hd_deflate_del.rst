
nghttp2_hd_deflate_del
======================

Synopsis
--------

*#include <nghttp2/nghttp2.h>*

.. function:: void nghttp2_hd_deflate_del(nghttp2_hd_deflater *deflater)

    
    Deallocates any resources allocated for *deflater*.
