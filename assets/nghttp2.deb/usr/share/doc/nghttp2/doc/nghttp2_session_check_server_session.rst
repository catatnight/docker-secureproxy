
nghttp2_session_check_server_session
====================================

Synopsis
--------

*#include <nghttp2/nghttp2.h>*

.. function:: int nghttp2_session_check_server_session(nghttp2_session *session)

    
    Returns nonzero if *session* is initialized as server side session.
