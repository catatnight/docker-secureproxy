
nghttp2_hd_deflate_new
======================

Synopsis
--------

*#include <nghttp2/nghttp2.h>*

.. function:: int nghttp2_hd_deflate_new(nghttp2_hd_deflater **deflater_ptr, size_t deflate_hd_table_bufsize_max)

    
    Initializes *\*deflater_ptr* for deflating name/values pairs.
    
    The *deflate_hd_table_bufsize_max* is the upper bound of header
    table size the deflater will use.
    
    If this function fails, *\*deflater_ptr* is left untouched.
    
    This function returns 0 if it succeeds, or one of the following
    negative error codes:
    
    :macro:`NGHTTP2_ERR_NOMEM`
        Out of memory.
