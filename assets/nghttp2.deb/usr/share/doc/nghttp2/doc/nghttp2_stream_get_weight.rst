
nghttp2_stream_get_weight
=========================

Synopsis
--------

*#include <nghttp2/nghttp2.h>*

.. function:: int32_t nghttp2_stream_get_weight(nghttp2_stream *stream)

    
    Returns dependency weight to the parent stream of *stream*.
