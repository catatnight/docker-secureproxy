.. include:: ../doc/sources/tutorial-client.rst

libevent-client.c
-----------------

.. literalinclude:: ../examples/libevent-client.c
