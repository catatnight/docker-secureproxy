
nghttp2_submit_data
===================

Synopsis
--------

*#include <nghttp2/nghttp2.h>*

.. function:: int nghttp2_submit_data(nghttp2_session *session, uint8_t flags, int32_t stream_id, const nghttp2_data_provider *data_prd)

    
    Submits one or more DATA frames to the stream *stream_id*.  The
    data to be sent are provided by *data_prd*.  If *flags* contains
    :macro:`NGHTTP2_FLAG_END_STREAM`, the last DATA frame has END_STREAM
    flag set.
    
    This function does not take ownership of the *data_prd*.  The
    function copies the members of the *data_prd*.
    
    This function returns 0 if it succeeds, or one of the following
    negative error codes:
    
    :macro:`NGHTTP2_ERR_NOMEM`
        Out of memory.
    :macro:`NGHTTP2_ERR_DATA_EXIST`
        DATA has been already submitted and not fully processed yet.
    :macro:`NGHTTP2_ERR_INVALID_ARGUMENT`
        The *stream_id* is 0.
    :macro:`NGHTTP2_ERR_STREAM_CLOSED`
        The stream was alreay closed; or the *stream_id* is invalid.
    
    .. note::
    
      Currently, only one data is allowed for a stream at a time.
      Submitting data more than once before first data is finished
      results in :macro:`NGHTTP2_ERR_DATA_EXIST` error code.  The
      earliest callback which tells that previous data is done is
      :type:`nghttp2_on_frame_send_callback`.  In side that callback,
      new data can be submitted using `nghttp2_submit_data()`.  Of
      course, all data except for last one must not have
      :macro:`NGHTTP2_FLAG_END_STREAM` flag set in *flags*.
